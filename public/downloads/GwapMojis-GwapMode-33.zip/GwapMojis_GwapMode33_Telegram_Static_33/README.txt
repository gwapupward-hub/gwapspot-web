GwapMojis — GwapMode 33
33 moods. 4 colors. One GWAP character.

This archive contains 33 Telegram-ready static sticker files derived from the exact
approved GwapMode 33 master artwork from this conversation.

The character artwork was not regenerated, restyled, recolored, or creatively edited.
Only technical resizing and WEBP encoding were performed for Telegram compatibility.

Contents:
- 33 transparent WEBP stickers
- 512 x 512 px
- each file <= 512 KB
- manifest.json with emoji associations

Release: free.
